// Export pages
export '/home_page/home_page_widget.dart' show HomePageWidget;
export '/main/main_widget.dart' show MainWidget;
export '/register/register_widget.dart' show RegisterWidget;
export '/main_copy/main_copy_widget.dart' show MainCopyWidget;
export '/main_copy_copy/main_copy_copy_widget.dart' show MainCopyCopyWidget;
export '/chnage_info/chnage_info_widget.dart' show ChnageInfoWidget;
export '/payment/payment_widget.dart' show PaymentWidget;
